var nome;

var media= function(n1, n2, n3, n4){
    let media;
    media = (n1 + n2 + n3 + n4)/4;
    alert(media) 
}

nome = prompt("Insira seu nome: ")
n1 = parseFloat(prompt("Digite a nota da primeira prova"))
n2 = parseFloat(prompt("Digite a nota da segunda prova"))
n3 = parseFloat(prompt("Digite a nota da terceira prova"))
n4 = parseFloat(prompt("Digite a nota da quarta prova"))
alert(media(n1,n2,n3,n4));

var numero1 = parseFloat(prompt("Digite o primeiro numero"))
var numero2 = parseFloat(prompt("Digite o segundo numero"))

var operacoes = function(n1,n2){
    let soma = n1+n2;
    let sub = n1-n2;
    let mult = n1*n2;
    let div = n1/n2;
    let resto = n1%n2;

    alert("Soma "+soma+
        "\nSubtração "+sub+
        "\nmultiplicação "+mult+
        "\ndivisão "+div+
        "\nresto "+resto
    )
}

operacoes(numero1, numero2);
